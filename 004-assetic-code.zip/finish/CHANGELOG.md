CHANGELOG
=========

Dec 2013
--------

- Fixing out-of-date fuzzy composer update syntax - issue: #3

March 2014
----------

- Screencast was completely re-recorded and updated. This included new changes
  for Symfony 2.4, a new tone of voice, and some minor changes to the screencast
  (but nothing very very significant).


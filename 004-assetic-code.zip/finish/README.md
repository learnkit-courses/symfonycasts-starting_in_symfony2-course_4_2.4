Starting in Symfony2 - Episode 1
================================

Well hallo there! If you're looking for the actual Symfony2 tutorial,
well that's over here: https://github.com/knpuniversity/symfony2-ep1

Inside this repository, you'll find a few great things:

1) The written script of the tutorial in the `knpu/` directory

2) Some files that we use during the screencast in `resources/`.

Since the project is started from nothing, there's nothing else you
need to get going! To see the finished version of the project, visit
the [finish branch](https://github.com/knpuniversity/symfony2-ep1/tree/finish).

And as always, thanks so much for your support and letting us do what
we love!

<3 Your friends at KnpLabs

